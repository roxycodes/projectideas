public class Main {
    public static void main(String[] args) {

        Hamburger hamburger = new Hamburger("White", "Sausage", 2.50, "Basic");
        hamburger.addHamburgerAddition1("Tomato", 0.29);
        double price = hamburger.itemizeHamburger();

        HealthyBurger healthyBurger = new HealthyBurger("Chicken", 4.60);
        healthyBurger.addHamburgerAddition1("Egg", 2.50);
        healthyBurger.addHealthAddition1("lentils", 3.20);
        healthyBurger.itemizeHamburger();
        System.out.println("Total healthy burger price is " + healthyBurger.itemizeHamburger());

        DeluxeBurger db = new DeluxeBurger("White", "Chicken", 4.50, "Deluxe");
        db.itemizeHamburger();
        System.out.println("Total Deluxe burger price is " + db.itemizeHamburger());


    }

}