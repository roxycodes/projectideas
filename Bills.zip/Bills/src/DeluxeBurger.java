public class DeluxeBurger extends Hamburger {

    public DeluxeBurger(String rollType, String meat, double price, String name) {
        super("White", "Sausage", 4.50, "Deluxe");
        super.addHamburgerAddition1("chips", 2.50);
        super.addHamburgerAddition2("drink", 1.50);
    }

    @Override
    public void addHamburgerAddition1(String name, double price) {
        System.out.println("Cannot add to deluxe burger");
    }

    @Override
    public void addHamburgerAddition2(String name, double price) {
        System.out.println("Cannot add to deluxe burger");
    }

    @Override
    public void addHamburgerAddition3(String name, double price) {
        System.out.println("Cannot add to deluxe burger");
    }

    @Override
    public void addHamburgerAddition4(String name, double price) {
        System.out.println("Cannot add to deluxe burger");
    }
}




