public class Hamburger {


    private String rollType;
    private String meat;
    private double price;
    private String name;

    private String addition1Name;
    private double addition1Price;

    private String addition2Name;
    private double addition2Price;

    private String addition3Name;
    private double addition3Price;

    private String addition4Name;
    private double addition4Price;

    public Hamburger(String rollType, String meat, double price, String name) {
        this.rollType = rollType;
        this.meat = meat;
        this.price = price;
        this.name = name;
    }

    public void addHamburgerAddition1(String name, double price) {
        this.addition1Name = name;
        this.addition1Price = price;
    }

    public void addHamburgerAddition2(String name, double price) {
        this.addition1Name = name;
        this.addition1Price = price;
    }

    public void addHamburgerAddition3(String name, double price) {
        this.addition1Name = name;
        this.addition1Price = price;
    }

    public void addHamburgerAddition4(String name, double price) {
        this.addition1Name = name;
        this.addition1Price = price;


    }

    public double itemizeHamburger () { //total price of hamburger
        double hamburgerPrice = this.price; //local variable hamburgerprice. this price is basic price
        System.out.print(this.name + " hamburger " + " on a " + this.rollType + " roll " + " price is " + this.price);

        if (this.addition1Name != null) { //if this is not equal to null then we increment hamburger price
            hamburgerPrice += this.addition1Price; //increment hamburger price
            System.out.println("Added " + this.addition1Name + " for an extra " + this.addition1Price);
        }
        if (this.addition2Name != null) { //if this is not equal to null then we increment hamburger price
            hamburgerPrice += this.addition2Price; //increment hamburger price
            System.out.println("Added " + this.addition2Name + " for an extra " + this.addition2Price);
        }
        if (this.addition3Name != null) { //if this is not equal to null then we increment hamburger price
            hamburgerPrice += this.addition3Price; //increment hamburger price
            System.out.println("Added " + this.addition3Name + " for an extra " + this.addition3Price);
        }

        if (this.addition4Name != null) { //if this is not equal to null then we increment hamburger price
            hamburgerPrice += this.addition4Price; //increment hamburger price
            System.out.println("Added " + this.addition4Name + " for an extra " + this.addition4Price);


        }
        return hamburgerPrice;
    }



    }



